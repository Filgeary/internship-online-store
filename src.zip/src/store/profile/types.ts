export type TProfileState = {
  data: TProfile | {};
  waiting: boolean;
};
