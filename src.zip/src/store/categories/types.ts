export type TCategoriesState = {
  list: string[];
  waiting: boolean;
};
