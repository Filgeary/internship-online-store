export type TLocaleState = {
  lang: TLangs;
};
