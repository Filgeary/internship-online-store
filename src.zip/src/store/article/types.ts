export type TArticleState = {
  data: TArticle | {};
  waiting: boolean;
};
